// @vitest-environment jsdom

import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const typesCode = readFileSync(
  path.resolve(__dirname, "../src/js/types.js"),
  "utf8"
);
const excelIoUtilCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-util.js"),
  "utf8"
);
const excelIoCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io.js"),
  "utf8"
);
const msOfficeCoreCode = readFileSync(
  path.resolve(__dirname, "../src/js/ms-office-core.js"),
  "utf8"
);
const excelIoZipCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-zip.js"),
  "utf8"
);
const excelIoNormalizeCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-normalize.js"),
  "utf8"
);
const excelIoPackageXmlCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-package-xml.js"),
  "utf8"
);
const excelIoWorksheetBuildCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-worksheet-build.js"),
  "utf8"
);
const excelIoWorksheetParseCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-worksheet-parse.js"),
  "utf8"
);
const excelIoWorkbookParseCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-workbook-parse.js"),
  "utf8"
);
const excelIoWorkbookBuildCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-workbook-build.js"),
  "utf8"
);
const excelIoStylesBuildCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-styles-build.js"),
  "utf8"
);
const excelIoStylesParseCode = readFileSync(
  path.resolve(__dirname, "../src/js/excel-io-styles-parse.js"),
  "utf8"
);
const msProjectAiViewsCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-ai-views.js"),
  "utf8"
);
const msProjectCalendarCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-calendar.js"),
  "utf8"
);
const msProjectSamplesCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-samples.js"),
  "utf8"
);
const msProjectCsvCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-csv.js"),
  "utf8"
);
const msProjectValidateHelpersCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-validate-helpers.js"),
  "utf8"
);
const msProjectValidateCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-validate.js"),
  "utf8"
);
const msProjectXmlDomCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-xml-dom.js"),
  "utf8"
);
const msProjectCodecCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-codec.js"),
  "utf8"
);
const msProjectMermaidCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-mermaid.js"),
  "utf8"
);
const msProjectXmlCode = readFileSync(
  path.resolve(__dirname, "../src/js/msproject-xml.js"),
  "utf8"
);
const projectWorkbookSchemaCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-workbook-schema.js"),
  "utf8"
);
const projectXlsxImportUtilCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-import-util.js"),
  "utf8"
);
const projectXlsxImportProjectCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-import-project.js"),
  "utf8"
);
const projectXlsxImportCalendarsCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-import-calendars.js"),
  "utf8"
);
const projectXlsxImportEntitiesCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-import-entities.js"),
  "utf8"
);
const projectXlsxImportCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-import.js"),
  "utf8"
);
const projectXlsxExportUtilCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-export-util.js"),
  "utf8"
);
const projectXlsxExportProjectCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-export-project.js"),
  "utf8"
);
const projectXlsxExportEntitiesCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-export-entities.js"),
  "utf8"
);
const projectXlsxExportCalendarsCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-export-calendars.js"),
  "utf8"
);
const projectXlsxExportCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx-export.js"),
  "utf8"
);
const projectXlsxCode = readFileSync(
  path.resolve(__dirname, "../src/js/project-xlsx.js"),
  "utf8"
);
const dependencyXml = readFileSync(
  path.resolve(__dirname, "../testdata/dependency.xml"),
  "utf8"
);

function bootModules() {
  new Function(`${typesCode}\n${excelIoUtilCode}\n${msOfficeCoreCode}\n${excelIoZipCode}\n${excelIoNormalizeCode}\n${excelIoPackageXmlCode}\n${excelIoWorksheetBuildCode}\n${excelIoWorksheetParseCode}\n${excelIoWorkbookParseCode}\n${excelIoWorkbookBuildCode}\n${excelIoStylesBuildCode}\n${excelIoStylesParseCode}\n${excelIoCode}\n${msProjectAiViewsCode}\n${msProjectCalendarCode}\n${msProjectSamplesCode}\n${msProjectCsvCode}\n${msProjectValidateHelpersCode}\n${msProjectValidateCode}\n${msProjectXmlDomCode}\n${msProjectCodecCode}\n${msProjectMermaidCode}\n${msProjectXmlCode}\n${projectWorkbookSchemaCode}\n${projectXlsxImportUtilCode}\n${projectXlsxImportProjectCode}\n${projectXlsxImportCalendarsCode}\n${projectXlsxImportEntitiesCode}\n${projectXlsxImportCode}\n${projectXlsxExportUtilCode}\n${projectXlsxExportProjectCode}\n${projectXlsxExportEntitiesCode}\n${projectXlsxExportCalendarsCode}\n${projectXlsxExportCode}\n${projectXlsxCode}`)();
  return {
    excelIo: globalThis.__mikuprojectExcelIo,
    xml: globalThis.__mikuprojectXml,
    projectXlsx: globalThis.__mikuprojectProjectXlsx
  };
}

function buildSampleWorkbook(mutator) {
  const { xml, projectXlsx } = bootModules();
  const model = xml.importMsProjectXml(xml.SAMPLE_XML);
  const workbook = projectXlsx.exportProjectWorkbook(model);
  if (mutator) {
    mutator(workbook);
  }
  return { xml, projectXlsx, model, workbook };
}

const SAMPLE_HOLIDAY_COUNT = 1;
const SAMPLE_FIRST_HOLIDAY_NAME = "春分の日";
const SAMPLE_FIRST_HOLIDAY_DATE = "2026-03-20";
const EDITABLE_FILL = "#FDE7C7";

describe("miku-project project xlsx", () => {
  it("converts ProjectModel into workbook sheets", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);

    const workbook = projectXlsx.exportProjectWorkbook(model);

    expect(workbook.sheets.map((sheet) => sheet.name)).toEqual([
      "Project",
      "Tasks",
      "Resources",
      "Assignments",
      "Calendars",
      "NonWorkingDays",
      "Options"
    ]);
    expect(workbook.sheets[0].mergedRanges).toEqual(["A11:B11"]);
    expect(workbook.sheets[0].dataValidations).toEqual([
      { type: "list", sqref: "B17", formula1: "Options!$A$2:$A$3", allowBlank: true }
    ]);
    expect(workbook.sheets[0].rows[0].cells[0].value).toBe("Project");
    expect(workbook.sheets[0].rows[0].cells[0].bold).toBe(true);
    expect(workbook.sheets[0].rows[0].cells[0].fontSize).toBe(16);
    expect(workbook.sheets[0].rows[0].cells[0].fillColor).toBe("#BFD7EA");
    expect(workbook.sheets[0].rows[0].cells[1].fillColor).toBe("#BFD7EA");
    expect(workbook.sheets[0].rows[1].cells[0].value).toBe("Basic Info");
    expect(workbook.sheets[0].rows[1].cells[0].fontSize).toBe(16);
    expect(workbook.sheets[0].rows[1].cells[1].fillColor).toBe("#BFD7EA");
    expect(workbook.sheets[0].rows[2].cells[0].value).toBe("Field");
    expect(workbook.sheets[0].rows[3].cells[0].value).toBe("Name");
    expect(workbook.sheets[0].rows[3].cells[1].value).toBe("miku-project開発");
    expect(workbook.sheets[0].rows[3].cells[1].fillColor).toBe(EDITABLE_FILL);
    expect(workbook.sheets[0].rows[4].cells[1].fillColor).toBe(EDITABLE_FILL);
    expect(workbook.sheets[0].rows[5].cells[1].fillColor).toBe(EDITABLE_FILL);
    expect(workbook.sheets[0].rows[6].cells[1].fillColor).toBe(EDITABLE_FILL);
    expect(workbook.sheets[0].rows[7].cells[1].value).toBe("2026-03-16");
    expect(workbook.sheets[0].rows[11].cells[0].value).toBe("Settings");
    expect(workbook.sheets[0].rows[12].cells[1].fillColor).toBe(EDITABLE_FILL);
  });

  it("maps tasks, resources, assignments, and calendars to tabular rows", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);

    const workbook = projectXlsx.exportProjectWorkbook(model);
    const tasksSheet = workbook.sheets.find((sheet) => sheet.name === "Tasks");
    const resourcesSheet = workbook.sheets.find((sheet) => sheet.name === "Resources");
    const assignmentsSheet = workbook.sheets.find((sheet) => sheet.name === "Assignments");
    const calendarsSheet = workbook.sheets.find((sheet) => sheet.name === "Calendars");
    const nonWorkingDaysSheet = workbook.sheets.find((sheet) => sheet.name === "NonWorkingDays");
    const optionsSheet = workbook.sheets.find((sheet) => sheet.name === "Options");

    expect(tasksSheet.mergedRanges).toEqual([]);
    expect(tasksSheet.rows[0].cells[0].value).toBe("Tasks");
    expect(tasksSheet.rows[0].cells[0].fontSize).toBe(14);
    expect(tasksSheet.rows[0].cells[0].fillColor).toBe("#D4E0EC");
    expect(tasksSheet.rows[1].cells[0].value).toBe("Task List");
    expect(tasksSheet.rows[1].cells[0].fontSize).toBe(14);
    expect(tasksSheet.rows[2].cells.map((cell) => cell.value)).toEqual([
      "UID",
      "ID",
      "Name",
      "OutlineLevel",
      "OutlineNumber",
      "WBS",
      "Start",
      "Finish",
      "Duration",
      "PercentComplete",
      "PercentWorkComplete",
      "Milestone",
      "Summary",
      "Critical",
      "CalendarUID",
      "Predecessors",
      "Notes"
    ]);
    expect(tasksSheet.rows[3].cells[2].value).toBe("基盤整備");
    expect(tasksSheet.rows[3].cells[6].value).toBe("2026-03-16 09:00:00");
    expect(tasksSheet.rows[3].cells[2].bold).toBe(true);
    expect(tasksSheet.rows[3].cells[2].fillColor).toBe(EDITABLE_FILL);
    expect(tasksSheet.rows[3].cells[12].fillColor).toBe(EDITABLE_FILL);
    expect(tasksSheet.rows[5].cells[2].value).toBe("初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）");
    expect(tasksSheet.rows[5].cells[8].fillColor).toBe(EDITABLE_FILL);
    expect(tasksSheet.rows[5].cells[8].border).toBe("thin");
    expect(tasksSheet.rows[5].cells[13].fillColor).toBe(EDITABLE_FILL);
    expect(tasksSheet.rows[5].cells[13].border).toBe("thin");
    expect(tasksSheet.rows[5].cells[14].fillColor).toBe(EDITABLE_FILL);
    expect(tasksSheet.rows[5].cells[14].border).toBe("thin");
    expect(tasksSheet.rows[5].cells[15].value).toBe("");
    expect(tasksSheet.rows[5].cells[15].fillColor).toBe(EDITABLE_FILL);
    expect(tasksSheet.rows[5].cells[15].border).toBe("thin");
    expect(tasksSheet.rows[5].cells[16].value).toBeUndefined();
    expect(tasksSheet.rows[5].cells[16].fillColor).toBe(EDITABLE_FILL);
    expect(tasksSheet.rows[5].cells[16].border).toBe("thin");
    expect(tasksSheet.dataValidations).toEqual([
      { type: "list", sqref: "L4:L16 M4:M16 N4:N16", formula1: "Options!$A$2:$A$3", allowBlank: true }
    ]);

    expect(resourcesSheet.mergedRanges).toEqual([]);
    expect(resourcesSheet.rows[0].cells[0].value).toBe("Resources");
    expect(resourcesSheet.rows[0].cells[0].fontSize).toBe(14);
    expect(resourcesSheet.rows[0].cells[0].fillColor).toBe("#C8E3D8");
    expect(resourcesSheet.rows[1].cells[0].value).toBe("Resource List");
    expect(resourcesSheet.rows[2].cells.map((cell) => cell.value)).toEqual([
      "UID",
      "ID",
      "Name",
      "Type",
      "Initials",
      "Group",
      "MaxUnits",
      "CalendarUID",
      "StandardRate",
      "OvertimeRate",
      "CostPerUse",
      "Work",
      "ActualWork",
      "RemainingWork"
    ]);
    expect(resourcesSheet.rows).toHaveLength(4);
    expect(resourcesSheet.rows[3].cells[0].value).toBe("1");
    expect(resourcesSheet.rows[3].cells[2].value).toBe("Mikuku");
    expect(resourcesSheet.rows[3].cells[4].value).toBe("M");
    expect(resourcesSheet.rows[3].cells[2].fillColor).toBe(EDITABLE_FILL);
    expect(resourcesSheet.rows[3].cells[5].fillColor).toBe(EDITABLE_FILL);
    expect(resourcesSheet.rows[3].cells[6].fillColor).toBe(EDITABLE_FILL);
    expect(resourcesSheet.rows[3].cells[7].fillColor).toBe(EDITABLE_FILL);
    expect(resourcesSheet.rows[3].cells[2].border).toBe("thin");

    expect(assignmentsSheet.mergedRanges).toEqual([]);
    expect(assignmentsSheet.rows[0].cells[0].value).toBe("Assignments");
    expect(assignmentsSheet.rows[0].cells[0].fontSize).toBe(14);
    expect(assignmentsSheet.rows[0].cells[0].fillColor).toBe("#D7D2EC");
    expect(assignmentsSheet.rows[1].cells[0].value).toBe("Assignment List");
    expect(assignmentsSheet.rows[2].cells.map((cell) => cell.value)).toEqual([
      "UID",
      "TaskUID",
      "TaskName",
      "ResourceUID",
      "ResourceName",
      "Start",
      "Finish",
      "Units",
      "Work",
      "ActualWork",
      "RemainingWork",
      "PercentWorkComplete"
    ]);
    expect(assignmentsSheet.rows).toHaveLength(5);
    expect(assignmentsSheet.rows[3].cells[0].value).toBe("1");
    expect(assignmentsSheet.rows[3].cells[2].value).toContain("初期実装");
    expect(assignmentsSheet.rows[3].cells[4].value).toBe("Mikuku");
    expect(assignmentsSheet.rows[4].cells[0].value).toBe("2");
    expect(assignmentsSheet.rows[4].cells[2].value).toContain("round-trip拡張");
    expect(assignmentsSheet.rows[4].cells[4].value).toBe("Mikuku");
    expect(assignmentsSheet.rows[3].cells[7].fillColor).toBe(EDITABLE_FILL);
    expect(assignmentsSheet.rows[3].cells[8].fillColor).toBe(EDITABLE_FILL);
    expect(assignmentsSheet.rows[3].cells[11].fillColor).toBe(EDITABLE_FILL);
    expect(assignmentsSheet.rows[3].cells[7].border).toBe("thin");

    expect(calendarsSheet.mergedRanges).toEqual([]);
    expect(calendarsSheet.rows[0].cells[0].value).toBe("Calendars");
    expect(calendarsSheet.rows[0].cells[0].fontSize).toBe(14);
    expect(calendarsSheet.rows[0].cells[0].fillColor).toBe("#D7E3C4");
    expect(calendarsSheet.rows[1].cells[0].value).toBe("Calendar List");
    expect(calendarsSheet.rows[2].cells.map((cell) => cell.value)).toEqual([
      "UID",
      "Name",
      "IsBaseCalendar",
      "BaseCalendarUID",
      "WeekDays",
      "Exceptions",
      "WorkWeeks"
    ]);
    expect(calendarsSheet.rows[3].cells[1].value).toBe("Standard");
    expect(calendarsSheet.rows[3].cells[1].fillColor).toBe(EDITABLE_FILL);
    expect(calendarsSheet.rows[3].cells[2].fillColor).toBe(EDITABLE_FILL);
    expect(calendarsSheet.rows[3].cells[2].value).toBe("○");
    expect(calendarsSheet.dataValidations).toEqual([
      { type: "list", sqref: "C4:C4", formula1: "Options!$A$2:$A$3", allowBlank: true }
    ]);

    expect(nonWorkingDaysSheet.mergedRanges).toEqual([]);
    expect(nonWorkingDaysSheet.rows[0].cells[0].value).toBe("NonWorkingDays");
    expect(nonWorkingDaysSheet.rows[0].cells[0].fontSize).toBe(14);
    expect(nonWorkingDaysSheet.rows[0].cells[0].fillColor).toBe("#E9C7D5");
    expect(nonWorkingDaysSheet.rows[1].cells[0].value).toBe("Calendar Exceptions");
    expect(nonWorkingDaysSheet.rows[2].cells.map((cell) => cell.value)).toEqual([
      "CalendarUID",
      "Index",
      "CalendarName",
      "Name",
      "Date",
      "FromDate",
      "ToDate",
      "DayWorking"
    ]);
    expect(nonWorkingDaysSheet.rows[3].cells[0].value).toBe("1");
    expect(nonWorkingDaysSheet.rows[3].cells[3].value).toBe(SAMPLE_FIRST_HOLIDAY_NAME);
    expect(nonWorkingDaysSheet.rows[3].cells[3].fillColor).toBe(EDITABLE_FILL);
    expect(nonWorkingDaysSheet.rows[3].cells[4].value).toBe(SAMPLE_FIRST_HOLIDAY_DATE);
    expect(nonWorkingDaysSheet.rows[3].cells[5].value).toBe(SAMPLE_FIRST_HOLIDAY_DATE);
    expect(nonWorkingDaysSheet.rows[3].cells[6].value).toBe(SAMPLE_FIRST_HOLIDAY_DATE);
    expect(nonWorkingDaysSheet.rows[3].cells[7].value).toBe("ー");
    expect(nonWorkingDaysSheet.rows[3].cells[4].fillColor).toBe(EDITABLE_FILL);
    expect(nonWorkingDaysSheet.rows[3].cells[5].fillColor).toBe(EDITABLE_FILL);
    expect(nonWorkingDaysSheet.rows[3].cells[6].fillColor).toBe(EDITABLE_FILL);
    expect(nonWorkingDaysSheet.rows[3].cells[7].fillColor).toBe(EDITABLE_FILL);
    expect(nonWorkingDaysSheet.dataValidations).toEqual([
      { type: "list", sqref: "H4:H4", formula1: "Options!$A$2:$A$3", allowBlank: true }
    ]);
    expect(nonWorkingDaysSheet.rows).toHaveLength(SAMPLE_HOLIDAY_COUNT + 3);

    expect(optionsSheet.rows[0].cells.map((cell) => cell.value)).toEqual(["BooleanChoice", "Meaning"]);
    expect(optionsSheet.rows[1].cells.map((cell) => cell.value)).toEqual(["○", "true"]);
    expect(optionsSheet.rows[2].cells.map((cell) => cell.value)).toEqual(["ー", "false"]);
  });

  it("can generate a real xlsx from ProjectModel through the workbook adapter", () => {
    const { excelIo, xml, projectXlsx } = bootModules();
    const codec = new excelIo.XlsxWorkbookCodec();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);

    const workbook = projectXlsx.exportProjectWorkbook(model);
    const bytes = codec.exportWorkbook(workbook);
    const entries = codec.listEntries(bytes);
    const projectSheetXml = new TextDecoder().decode(codec.unpackEntries(bytes)["xl/worksheets/sheet1.xml"]);
    const optionsSheetXml = new TextDecoder().decode(codec.unpackEntries(bytes)["xl/worksheets/sheet7.xml"]);

    expect(entries).toContain("xl/workbook.xml");
    expect(entries).toContain("xl/worksheets/sheet1.xml");
    expect(entries).toContain("xl/styles.xml");
    expect(projectSheetXml).not.toContain('ref="A1:B1"');
    expect(projectSheetXml).toContain('ref="A11:B11"');
    expect(projectSheetXml).toContain('t="inlineStr"><is><t>1</t></is>');
    expect(projectSheetXml).toContain('<dataValidation type="list" allowBlank="1" showErrorMessage="1" sqref="B17"><formula1>Options!$A$2:$A$3</formula1></dataValidation>');
    expect(projectSheetXml).toContain('t="inlineStr"><is><t>○</t></is>');
    expect(optionsSheetXml).toContain('t="inlineStr"><is><t>BooleanChoice</t></is>');
    expect(optionsSheetXml).toContain('t="inlineStr"><is><t>○</t></is>');
    expect(optionsSheetXml).toContain('t="inlineStr"><is><t>ー</t></is>');
  });

  it("imports limited task fields from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const tasksSheet = workbook.sheets.find((sheet) => sheet.name === "Tasks");

    tasksSheet.rows[5].cells[2].value = "初期実装 Updated";
    tasksSheet.rows[5].cells[6].value = "2026-03-17";
    tasksSheet.rows[5].cells[7].value = "2026-03-18";
    tasksSheet.rows[5].cells[8].value = "PT24H0M0S";
    tasksSheet.rows[5].cells[9].value = 80;
    tasksSheet.rows[5].cells[10].value = 90;
    tasksSheet.rows[5].cells[11].value = "○";
    tasksSheet.rows[5].cells[12].value = "○";
    tasksSheet.rows[5].cells[13].value = "ー";
    tasksSheet.rows[5].cells[14].value = "2";
    tasksSheet.rows[5].cells[15].value = "2";
    tasksSheet.rows[5].cells[16].value = "Updated Notes";

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);
    const designTask = importedModel.tasks.find((task) => task.uid === "3");
    const implementationTask = importedModel.tasks.find((task) => task.uid === "4");

    expect(designTask.name).toBe("初期実装 Updated");
    expect(designTask.start).toBe("2026-03-17");
    expect(designTask.finish).toBe("2026-03-18");
    expect(designTask.duration).toBe("PT24H0M0S");
    expect(designTask.percentComplete).toBe(80);
    expect(designTask.percentWorkComplete).toBe(90);
    expect(designTask.milestone).toBe(true);
    expect(designTask.summary).toBe(true);
    expect(designTask.critical).toBe(false);
    expect(designTask.calendarUID).toBe("2");
    expect(designTask.predecessors).toEqual([{ predecessorUid: "2" }]);
    expect(designTask.notes).toBe("Updated Notes");
    expect(implementationTask.name).toBe("round-trip拡張（MS Project XML → 内部JSON形式 → MS Project XML の往復対応）");
  });

  it("imports limited resource and assignment fields from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(dependencyXml);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const resourcesSheet = workbook.sheets.find((sheet) => sheet.name === "Resources");
    resourcesSheet.rows[3].cells[2].value = "Miku Updated";
    resourcesSheet.rows[3].cells[5].value = "Dev";
    resourcesSheet.rows[3].cells[6].value = 1;
    resourcesSheet.rows[3].cells[7].value = "1";
    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);

    expect(importedModel.resources[0].name).toBe("Miku Updated");
    expect(importedModel.resources[0].group).toBe("Dev");
    expect(importedModel.resources[0].maxUnits).toBe(1);
    expect(importedModel.resources[0].calendarUID).toBe("1");
    expect(importedModel.assignments).toHaveLength(1);
  });

  it("imports limited project fields from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const projectSheet = workbook.sheets.find((sheet) => sheet.name === "Project");

    projectSheet.rows[3].cells[1].value = "Renamed Project";
    projectSheet.rows[7].cells[1].value = "2026-03-15 09:00:00";
    projectSheet.rows[12].cells[1].value = "2";
    projectSheet.rows[13].cells[1].value = 420;
    projectSheet.rows[16].cells[1].value = false;

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);

    expect(importedModel.project.name).toBe("Renamed Project");
    expect(importedModel.project.startDate).toBe("2026-03-15T09:00:00");
    expect(importedModel.project.calendarUID).toBe("2");
    expect(importedModel.project.minutesPerDay).toBe(420);
    expect(importedModel.project.scheduleFromStart).toBe(false);
  });

  it("imports project calendar and schedule mode fields from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const projectSheet = workbook.sheets.find((sheet) => sheet.name === "Project");

    projectSheet.rows[12].cells[1].value = "2";
    projectSheet.rows[16].cells[1].value = false;

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);

    expect(importedModel.project.calendarUID).toBe("2");
    expect(importedModel.project.scheduleFromStart).toBe(false);
  });

  it("imports project metadata and date fields from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const projectSheet = workbook.sheets.find((sheet) => sheet.name === "Project");

    projectSheet.rows[4].cells[1].value = "Updated Title";
    projectSheet.rows[6].cells[1].value = "Updated Company";
    projectSheet.rows[7].cells[1].value = "2026-03-15T09:00:00";
    projectSheet.rows[8].cells[1].value = "2026-03-28T18:00:00";

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);

    expect(importedModel.project.title).toBe("Updated Title");
    expect(importedModel.project.company).toBe("Updated Company");
    expect(importedModel.project.startDate).toBe("2026-03-15T09:00:00");
    expect(importedModel.project.finishDate).toBe("2026-03-28T18:00:00");
  });

  it("imports project author field from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const projectSheet = workbook.sheets.find((sheet) => sheet.name === "Project");

    projectSheet.rows[5].cells[1].value = "Author From XLSX";

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);

    expect(importedModel.project.author).toBe("Author From XLSX");
  });

  it("imports project current and status dates plus weekly settings from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const projectSheet = workbook.sheets.find((sheet) => sheet.name === "Project");

    projectSheet.rows[9].cells[1].value = "2026-03-18T09:00:00";
    projectSheet.rows[10].cells[1].value = "2026-03-22T09:00:00";
    projectSheet.rows[14].cells[1].value = 2100;
    projectSheet.rows[15].cells[1].value = 18;

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);

    expect(importedModel.project.currentDate).toBe("2026-03-18T09:00:00");
    expect(importedModel.project.statusDate).toBe("2026-03-22T09:00:00");
    expect(importedModel.project.minutesPerWeek).toBe(2100);
    expect(importedModel.project.daysPerMonth).toBe(18);
  });

  it("reports field-level import changes", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const tasksSheet = workbook.sheets.find((sheet) => sheet.name === "Tasks");

    tasksSheet.rows[5].cells[2].value = "初期実装 Updated";
    tasksSheet.rows[5].cells[8].value = "PT24H0M0S";
    tasksSheet.rows[5].cells[9].value = 80;
    tasksSheet.rows[5].cells[11].value = "○";
    tasksSheet.rows[5].cells[12].value = "○";
    tasksSheet.rows[5].cells[13].value = "ー";
    tasksSheet.rows[5].cells[14].value = "2";
    tasksSheet.rows[5].cells[15].value = "2";
    tasksSheet.rows[5].cells[16].value = "Updated Notes";

    const result = projectXlsx.importProjectWorkbookDetailed(workbook, model);

    expect(result.changes).toEqual([
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "Name", before: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", after: "初期実装 Updated" },
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "Duration", before: "PT0H0M0S", after: "PT24H0M0S" },
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "PercentComplete", before: 100, after: 80 },
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "Milestone", before: false, after: true },
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "Summary", before: false, after: true },
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "Critical", before: undefined, after: false },
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "CalendarUID", before: undefined, after: "2" },
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "Predecessors", before: undefined, after: "2" },
      { scope: "tasks", uid: "3", label: "初期実装（MS Project XML 調査・基軸フォーマット選定・内部モデルの概要確定）", field: "Notes", before: undefined, after: "Updated Notes" }
    ]);
  });

  it("ignores non-editable task columns during workbook import", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const tasksSheet = workbook.sheets.find((sheet) => sheet.name === "Tasks");

    tasksSheet.rows[5].cells[1].value = "999";
    tasksSheet.rows[5].cells[3].value = 9;
    tasksSheet.rows[5].cells[4].value = "9.9";
    tasksSheet.rows[5].cells[5].value = "WBS-999";

    const result = projectXlsx.importProjectWorkbookDetailed(workbook, model);
    const importedTask = result.model.tasks.find((task) => task.uid === "3");

    expect(importedTask.id).toBe(model.tasks.find((task) => task.uid === "3").id);
    expect(importedTask.outlineLevel).toBe(model.tasks.find((task) => task.uid === "3").outlineLevel);
    expect(importedTask.outlineNumber).toBe(model.tasks.find((task) => task.uid === "3").outlineNumber);
    expect(importedTask.wbs).toBe(model.tasks.find((task) => task.uid === "3").wbs);
    expect(result.changes).toEqual([]);
  });

  it("reports project-level import changes", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const projectSheet = workbook.sheets.find((sheet) => sheet.name === "Project");

    projectSheet.rows[3].cells[1].value = "Renamed Project";
    projectSheet.rows[13].cells[1].value = 420;

    const result = projectXlsx.importProjectWorkbookDetailed(workbook, model);

    expect(result.changes).toEqual([
      { scope: "project", uid: "project", label: "miku-project開発", field: "Name", before: "miku-project開発", after: "Renamed Project" },
      { scope: "project", uid: "project", label: "miku-project開発", field: "MinutesPerDay", before: 480, after: 420 }
    ]);
  });

  it("imports limited calendar fields from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const calendarsSheet = workbook.sheets.find((sheet) => sheet.name === "Calendars");

    calendarsSheet.rows[3].cells[1].value = "Standard Updated";
    calendarsSheet.rows[3].cells[3].value = "2";

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);

    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").name).toBe("Standard Updated");
    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").baseCalendarUID).toBe("2");
  });

  it("reports calendar-level import changes", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const calendarsSheet = workbook.sheets.find((sheet) => sheet.name === "Calendars");

    calendarsSheet.rows[3].cells[1].value = "Standard Updated";
    calendarsSheet.rows[3].cells[3].value = "2";

    const result = projectXlsx.importProjectWorkbookDetailed(workbook, model);

    expect(result.changes).toEqual([
      { scope: "calendars", uid: "1", label: "Standard", field: "Name", before: "Standard", after: "Standard Updated" },
      { scope: "calendars", uid: "1", label: "Standard", field: "BaseCalendarUID", before: undefined, after: "2" }
    ]);
  });

  it("imports calendar isBaseCalendar field from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const calendarsSheet = workbook.sheets.find((sheet) => sheet.name === "Calendars");

    calendarsSheet.rows[3].cells[2].value = false;

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);

    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").isBaseCalendar).toBe(false);
  });

  it("ignores calendar WeekDays, Exceptions, and WorkWeeks workbook edits", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const calendarsSheet = workbook.sheets.find((sheet) => sheet.name === "Calendars");

    calendarsSheet.rows[3].cells[4].value = 77;
    calendarsSheet.rows[3].cells[5].value = 88;
    calendarsSheet.rows[3].cells[6].value = 99;

    const result = projectXlsx.importProjectWorkbookDetailed(workbook, model);

    expect(result.model.calendars.find((calendar) => calendar.uid === "1").weekDays).toHaveLength(7);
    expect(result.model.calendars.find((calendar) => calendar.uid === "1").exceptions).toHaveLength(SAMPLE_HOLIDAY_COUNT);
    expect(result.model.calendars.find((calendar) => calendar.uid === "1").workWeeks).toHaveLength(0);
    expect(result.changes).toEqual([]);
  });

  it("imports non-working day sheet fields from workbook rows back into ProjectModel", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const nonWorkingDaysSheet = workbook.sheets.find((sheet) => sheet.name === "NonWorkingDays");

    nonWorkingDaysSheet.rows[3].cells[3].value = "Spring Holiday";
    nonWorkingDaysSheet.rows[3].cells[4].value = "2026-03-21";
    nonWorkingDaysSheet.rows[3].cells[7].value = false;

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);
    const exception = importedModel.calendars.find((calendar) => calendar.uid === "1").exceptions[0];

    expect(exception.name).toBe("Spring Holiday");
    expect(exception.fromDate).toBe("2026-03-21T00:00:00");
    expect(exception.toDate).toBe("2026-03-21T23:59:59");
    expect(exception.dayWorking).toBe(false);
  });

  it("reports non-working day import changes", () => {
    const { xml, projectXlsx } = bootModules();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);
    const nonWorkingDaysSheet = workbook.sheets.find((sheet) => sheet.name === "NonWorkingDays");

    nonWorkingDaysSheet.rows[3].cells[3].value = "Spring Holiday";
    nonWorkingDaysSheet.rows[3].cells[4].value = "2026-03-21";

    const result = projectXlsx.importProjectWorkbookDetailed(workbook, model);

    expect(result.changes).toEqual([
      { scope: "calendars", uid: "1", label: "Standard", field: "Exception1.Name", before: SAMPLE_FIRST_HOLIDAY_NAME, after: "Spring Holiday" },
      { scope: "calendars", uid: "1", label: "Standard", field: "Exception1.FromDate", before: `${SAMPLE_FIRST_HOLIDAY_DATE}T00:00:00`, after: "2026-03-21T00:00:00" },
      { scope: "calendars", uid: "1", label: "Standard", field: "Exception1.ToDate", before: `${SAMPLE_FIRST_HOLIDAY_DATE}T23:59:59`, after: "2026-03-21T23:59:59" }
    ]);
  });

  it("reports assignment percent work complete import changes", () => {
    const { projectXlsx, model, workbook } = buildSampleWorkbook((nextWorkbook) => {
      const assignmentsSheet = nextWorkbook.sheets.find((sheet) => sheet.name === "Assignments");
      expect(assignmentsSheet.rows).toHaveLength(5);
    });

    const result = projectXlsx.importProjectWorkbookDetailed(workbook, model);

    expect(result.changes).toEqual([]);
  });

  it("can validate imported task percent complete out of range without UI boot", () => {
    const { xml, projectXlsx, model, workbook } = buildSampleWorkbook((nextWorkbook) => {
      const tasksSheet = nextWorkbook.sheets.find((sheet) => sheet.name === "Tasks");
      tasksSheet.rows[5].cells[9].value = 120;
    });

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);
    const issues = xml.validateProjectModel(importedModel);

    expect(importedModel.tasks.find((task) => task.uid === "3").percentComplete).toBe(120);
    expect(issues).toHaveLength(1);
    expect(issues[0].level).toBe("warning");
    expect(issues[0].message).toContain("PercentComplete");
    expect(issues[0].message).toContain("0..100");
  });

  it("can validate imported task start later than finish without UI boot", () => {
    const { xml, projectXlsx, model, workbook } = buildSampleWorkbook((nextWorkbook) => {
      const tasksSheet = nextWorkbook.sheets.find((sheet) => sheet.name === "Tasks");
      tasksSheet.rows[5].cells[6].value = "2026-03-19";
      tasksSheet.rows[5].cells[7].value = "2026-03-18";
    });

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);
    const issues = xml.validateProjectModel(importedModel);

    expect(importedModel.tasks.find((task) => task.uid === "3").start).toBe("2026-03-19");
    expect(importedModel.tasks.find((task) => task.uid === "3").finish).toBe("2026-03-18");
    expect(issues).toHaveLength(1);
    expect(issues[0].level).toBe("warning");
    expect(issues[0].message).toContain("Start");
    expect(issues[0].message).toContain("Finish");
  });

  it("can validate imported missing calendar baseCalendarUID without UI boot", () => {
    const { xml, projectXlsx, model, workbook } = buildSampleWorkbook((nextWorkbook) => {
      const calendarsSheet = nextWorkbook.sheets.find((sheet) => sheet.name === "Calendars");
      calendarsSheet.rows[3].cells[3].value = "99";
    });

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);
    const issues = xml.validateProjectModel(importedModel);

    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").baseCalendarUID).toBe("99");
    expect(issues).toHaveLength(1);
    expect(issues[0].level).toBe("warning");
    expect(issues[0].message).toContain("BaseCalendarUID");
    expect(issues[0].message).toContain("指していません");
  });

  it("can validate imported self-referencing calendar baseCalendarUID without UI boot", () => {
    const { xml, projectXlsx, model, workbook } = buildSampleWorkbook((nextWorkbook) => {
      const calendarsSheet = nextWorkbook.sheets.find((sheet) => sheet.name === "Calendars");
      calendarsSheet.rows[3].cells[3].value = "1";
    });

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);
    const issues = xml.validateProjectModel(importedModel);

    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").baseCalendarUID).toBe("1");
    expect(issues).toHaveLength(1);
    expect(issues[0].level).toBe("warning");
    expect(issues[0].message).toContain("BaseCalendarUID");
    expect(issues[0].message).toContain("自身を指しています");
  });

  it("can export xml after imported xlsx edits without UI boot", () => {
    const { xml, projectXlsx, model, workbook } = buildSampleWorkbook((nextWorkbook) => {
      const tasksSheet = nextWorkbook.sheets.find((sheet) => sheet.name === "Tasks");
      tasksSheet.rows[5].cells[2].value = "初期実装 Saved From XLSX";
    });

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);
    const exportedXml = xml.exportMsProjectXml(importedModel);

    expect(exportedXml).toContain("<Name>初期実装 Saved From XLSX</Name>");
  });

  it("can export xml after imported invalid xlsx edits without UI boot", () => {
    const { xml, projectXlsx, model, workbook } = buildSampleWorkbook((nextWorkbook) => {
      const tasksSheet = nextWorkbook.sheets.find((sheet) => sheet.name === "Tasks");
      tasksSheet.rows[5].cells[6].value = "2026-03-19";
      tasksSheet.rows[5].cells[7].value = "2026-03-18";
    });

    const importedModel = projectXlsx.importProjectWorkbook(workbook, model);
    const issues = xml.validateProjectModel(importedModel);
    const exportedXml = xml.exportMsProjectXml(importedModel);

    expect(issues).toHaveLength(1);
    expect(issues[0].level).toBe("warning");
    expect(issues[0].message).toContain("Start");
    expect(issues[0].message).toContain("Finish");
    expect(exportedXml).toContain("<Start>2026-03-19</Start>");
    expect(exportedXml).toContain("<Finish>2026-03-18</Finish>");
  });

  it("round-trips editable fields through workbook and xlsx bytes", () => {
    const { excelIo, xml, projectXlsx } = bootModules();
    const codec = new excelIo.XlsxWorkbookCodec();
    const model = xml.importMsProjectXml(xml.SAMPLE_XML);
    const workbook = projectXlsx.exportProjectWorkbook(model);

    const tasksSheet = workbook.sheets.find((sheet) => sheet.name === "Tasks");
    const resourcesSheet = workbook.sheets.find((sheet) => sheet.name === "Resources");
    const assignmentsSheet = workbook.sheets.find((sheet) => sheet.name === "Assignments");
    const calendarsSheet = workbook.sheets.find((sheet) => sheet.name === "Calendars");
    const nonWorkingDaysSheet = workbook.sheets.find((sheet) => sheet.name === "NonWorkingDays");

    tasksSheet.rows[5].cells[2].value = "初期実装 via XLSX";
    tasksSheet.rows[5].cells[8].value = "PT24H0M0S";
    tasksSheet.rows[5].cells[9].value = 60;
    tasksSheet.rows[5].cells[11].value = "○";
    tasksSheet.rows[5].cells[12].value = "○";
    tasksSheet.rows[5].cells[13].value = "ー";
    tasksSheet.rows[5].cells[14].value = "2";
    tasksSheet.rows[5].cells[15].value = "2";
    tasksSheet.rows[5].cells[16].value = "初期実装 notes via XLSX";
    calendarsSheet.rows[3].cells[1].value = "Standard via XLSX";
    calendarsSheet.rows[3].cells[2].value = true;
    calendarsSheet.rows[3].cells[3].value = "1";
    nonWorkingDaysSheet.rows[3].cells[3].value = "Holiday via XLSX";
    nonWorkingDaysSheet.rows[3].cells[4].value = "2026-03-22";

    const bytes = codec.exportWorkbook(workbook);
    const importedWorkbook = codec.importWorkbook(bytes);
    const importedModel = projectXlsx.importProjectWorkbook(importedWorkbook, model);

    expect(importedModel.tasks.find((task) => task.uid === "3").name).toBe("初期実装 via XLSX");
    expect(importedModel.tasks.find((task) => task.uid === "3").duration).toBe("PT24H0M0S");
    expect(importedModel.tasks.find((task) => task.uid === "3").percentComplete).toBe(60);
    expect(importedModel.tasks.find((task) => task.uid === "3").milestone).toBe(true);
    expect(importedModel.tasks.find((task) => task.uid === "3").summary).toBe(true);
    expect(importedModel.tasks.find((task) => task.uid === "3").critical).toBe(false);
    expect(importedModel.tasks.find((task) => task.uid === "3").calendarUID).toBe("2");
    expect(importedModel.tasks.find((task) => task.uid === "3").predecessors).toEqual([{ predecessorUid: "2" }]);
    expect(importedModel.tasks.find((task) => task.uid === "3").notes).toBe("初期実装 notes via XLSX");
    expect(importedModel.resources).toHaveLength(1);
    expect(importedModel.resources[0].name).toBe("Mikuku");
    expect(importedModel.resources[0].initials).toBe("M");
    expect(importedModel.assignments).toHaveLength(2);
    expect(importedModel.assignments[0].taskUid).toBe("3");
    expect(importedModel.assignments[0].resourceUid).toBe("1");
    expect(importedModel.assignments[1].taskUid).toBe("4");
    expect(importedModel.assignments[1].resourceUid).toBe("1");
    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").name).toBe("Standard via XLSX");
    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").isBaseCalendar).toBe(true);
    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").baseCalendarUID).toBe("1");
    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").exceptions[0].name).toBe("Holiday via XLSX");
    expect(importedModel.calendars.find((calendar) => calendar.uid === "1").exceptions[0].fromDate).toBe("2026-03-22T00:00:00");
  });
});
