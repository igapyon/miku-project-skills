var __mikuMsOfficeCoreRelease = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var stdin_exports = {};
  __export(stdin_exports, {
    asBytes: () => asBytes,
    buildOpcContentTypesXml: () => buildOpcContentTypesXml,
    buildOpcRelationshipsPath: () => buildOpcRelationshipsPath,
    buildOpcRelationshipsXml: () => buildOpcRelationshipsXml,
    compareOpcPartPaths: () => compareOpcPartPaths,
    concatBytes: () => concatBytes,
    createDiagnostic: () => createDiagnostic,
    decodeXmlEntities: () => decodeXmlEntities,
    escapeXmlAttribute: () => escapeXmlAttribute,
    escapeXmlText: () => escapeXmlText,
    getDefaultZipEntryTimestamp: () => getDefaultZipEntryTimestamp,
    getZipEntry: () => getZipEntry,
    getZipTextEntry: () => getZipTextEntry,
    listOfficeMediaParts: () => listOfficeMediaParts,
    normalizeOpcPartPath: () => normalizeOpcPartPath,
    parseOpcContentTypesXml: () => parseOpcContentTypesXml,
    parseOpcRelationshipsXml: () => parseOpcRelationshipsXml,
    parseXmlAttributes: () => parseXmlAttributes,
    readOfficePackage: () => readOfficePackage,
    readOfficePackageAsync: () => readOfficePackageAsync,
    readOfficePartRelationships: () => readOfficePartRelationships,
    readUint16: () => readUint16,
    readUint32: () => readUint32,
    readZipPackage: () => readZipPackage,
    readZipPackageAsync: () => readZipPackageAsync,
    relationshipArrayToMap: () => relationshipArrayToMap,
    resolveOpcContentType: () => resolveOpcContentType,
    resolveOpcRelationshipTarget: () => resolveOpcRelationshipTarget,
    resolveOpcRelationships: () => resolveOpcRelationships,
    sanitizeXmlText: () => sanitizeXmlText,
    textDecoder: () => textDecoder,
    textEncoder: () => textEncoder,
    upsertZipEntry: () => upsertZipEntry,
    writeUint16: () => writeUint16,
    writeUint32: () => writeUint32,
    writeZipPackage: () => writeZipPackage
  });
  var textEncoder = new TextEncoder();
  var textDecoder = new TextDecoder();
  function readUint16(data, offset) {
    return data[offset] | data[offset + 1] << 8;
  }
  function readUint32(data, offset) {
    return (data[offset] | data[offset + 1] << 8 | data[offset + 2] << 16 | data[offset + 3] << 24) >>> 0;
  }
  function writeUint16(buffer, offset, value) {
    buffer[offset] = value & 255;
    buffer[offset + 1] = value >>> 8 & 255;
  }
  function writeUint32(buffer, offset, value) {
    buffer[offset] = value & 255;
    buffer[offset + 1] = value >>> 8 & 255;
    buffer[offset + 2] = value >>> 16 & 255;
    buffer[offset + 3] = value >>> 24 & 255;
  }
  function concatBytes(parts) {
    const total = parts.reduce((sum, part) => sum + part.length, 0);
    const output = new Uint8Array(total);
    let offset = 0;
    for (const part of parts) {
      output.set(part, offset);
      offset += part.length;
    }
    return output;
  }
  function asBytes(data) {
    return typeof data === "string" ? textEncoder.encode(data) : data;
  }
  function createDiagnostic(severity, code, message, path) {
    return path === void 0 ? { severity, code, message } : { severity, code, message, path };
  }
  function normalizeOpcPartPath(partPath) {
    var _a;
    const withoutHash = (_a = partPath.split("#", 1)[0]) != null ? _a : "";
    const raw = withoutHash.replace(/\\/g, "/").replace(/^\/+/, "");
    const parts = [];
    for (const part of raw.split("/")) {
      if (part === "" || part === ".") {
        continue;
      }
      if (part === "..") {
        if (parts.length === 0) {
          throw new Error(`OPC part path escapes package root: ${partPath}`);
        }
        parts.pop();
        continue;
      }
      parts.push(part);
    }
    if (parts.length === 0) {
      throw new Error(`OPC part path is empty: ${partPath}`);
    }
    return parts.join("/");
  }
  function resolveOpcRelationshipTarget(sourcePartPath, target, targetMode = "") {
    if (targetMode.toLowerCase() === "external") {
      return target;
    }
    if (/^[a-z][a-z0-9+.-]*:/i.test(target)) {
      return target;
    }
    if (target.startsWith("/")) {
      return normalizeOpcPartPath(target);
    }
    const source = normalizeOpcPartPath(sourcePartPath);
    const sourceDirectory = source.includes("/") ? source.slice(0, source.lastIndexOf("/")) : "";
    return normalizeOpcPartPath(sourceDirectory === "" ? target : `${sourceDirectory}/${target}`);
  }
  function compareOpcPartPaths(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }
  function buildOpcRelationshipsPath(sourcePartPath) {
    const source = normalizeOpcPartPath(sourcePartPath);
    const slashIndex = source.lastIndexOf("/");
    const directory = slashIndex < 0 ? "" : source.slice(0, slashIndex);
    const fileName = slashIndex < 0 ? source : source.slice(slashIndex + 1);
    return directory === "" ? `_rels/${fileName}.rels` : `${directory}/_rels/${fileName}.rels`;
  }
  function escapeXmlText(value) {
    return sanitizeXmlText(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function escapeXmlAttribute(value) {
    return escapeXmlText(value).replace(/"/g, "&quot;").replace(/'/g, "&apos;");
  }
  function sanitizeXmlText(value) {
    return value.replace(/[^\u0009\u000A\u000D\u0020-\uD7FF\uE000-\uFFFD]/g, "");
  }
  function parseXmlAttributes(tag) {
    var _a, _b;
    const attributes = /* @__PURE__ */ new Map();
    const pattern = /([A-Za-z_][\w:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
    for (const match of tag.matchAll(pattern)) {
      attributes.set(match[1], decodeXmlEntities((_b = (_a = match[2]) != null ? _a : match[3]) != null ? _b : ""));
    }
    return attributes;
  }
  function decodeXmlEntities(value) {
    return value.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  }
  function parseOpcContentTypesXml(xml) {
    var _a, _b;
    const defaults = [];
    const overrides = [];
    for (const match of xml.matchAll(/<Default\b([^>]*)\/?>/g)) {
      const attributes = parseXmlAttributes((_a = match[1]) != null ? _a : "");
      const extension = attributes.get("Extension");
      const contentType = attributes.get("ContentType");
      if (extension !== void 0 && contentType !== void 0) {
        defaults.push({ extension, contentType });
      }
    }
    for (const match of xml.matchAll(/<Override\b([^>]*)\/?>/g)) {
      const attributes = parseXmlAttributes((_b = match[1]) != null ? _b : "");
      const partName = attributes.get("PartName");
      const contentType = attributes.get("ContentType");
      if (partName !== void 0 && contentType !== void 0) {
        overrides.push({ partName: normalizeOpcPartPath(partName), contentType });
      }
    }
    return { defaults, overrides };
  }
  function resolveOpcContentType(contentTypes, partPath) {
    var _a;
    const normalized = normalizeOpcPartPath(partPath);
    const override = contentTypes.overrides.find((item) => item.partName === normalized);
    if (override !== void 0) {
      return override.contentType;
    }
    const extension = normalized.includes(".") ? normalized.slice(normalized.lastIndexOf(".") + 1) : "";
    return (_a = contentTypes.defaults.find((item) => item.extension === extension)) == null ? void 0 : _a.contentType;
  }
  function buildOpcContentTypesXml(contentTypes) {
    const defaults = contentTypes.defaults.map((item) => `<Default Extension="${escapeXmlAttribute(item.extension)}" ContentType="${escapeXmlAttribute(item.contentType)}"/>`).join("");
    const overrides = contentTypes.overrides.map((item) => `<Override PartName="/${escapeXmlAttribute(normalizeOpcPartPath(item.partName))}" ContentType="${escapeXmlAttribute(item.contentType)}"/>`).join("");
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">${defaults}${overrides}</Types>`;
  }
  function parseOpcRelationshipsXml(xml) {
    var _a;
    const relationships = [];
    const pattern = /<Relationship\b([^>]*)\/?>/g;
    for (const match of xml.matchAll(pattern)) {
      const attributes = parseXmlAttributes((_a = match[1]) != null ? _a : "");
      const id = attributes.get("Id");
      const type = attributes.get("Type");
      const target = attributes.get("Target");
      if (id === void 0 || type === void 0 || target === void 0) {
        continue;
      }
      const targetMode = attributes.get("TargetMode");
      relationships.push(
        targetMode === void 0 ? { id, type, target } : { id, type, target, targetMode }
      );
    }
    return relationships;
  }
  function buildOpcRelationshipsXml(relationships) {
    const rels = relationships.map((relationship) => {
      const targetMode = relationship.targetMode === void 0 ? "" : ` TargetMode="${escapeXmlAttribute(relationship.targetMode)}"`;
      return `<Relationship Id="${escapeXmlAttribute(relationship.id)}" Type="${escapeXmlAttribute(relationship.type)}" Target="${escapeXmlAttribute(relationship.target)}"${targetMode}/>`;
    }).join("");
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels}</Relationships>`;
  }
  function resolveOpcRelationships(relationships, sourcePartPath) {
    return relationships.map((relationship) => ({
      ...relationship,
      target: resolveOpcRelationshipTarget(sourcePartPath, relationship.target, relationship.targetMode)
    }));
  }
  function relationshipArrayToMap(relationships) {
    return new Map(relationships.map((relationship) => [relationship.id, relationship]));
  }
  var crcTable = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let c = i;
    for (let k = 0; k < 8; k += 1) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    crcTable[i] = c >>> 0;
  }
  function crc32(data) {
    let crc = 4294967295;
    for (const value of data) {
      crc = crcTable[(crc ^ value) & 255] ^ crc >>> 8;
    }
    return (crc ^ 4294967295) >>> 0;
  }
  var EOCD_SIGNATURE = 101010256;
  var CENTRAL_DIRECTORY_SIGNATURE = 33639248;
  var LOCAL_FILE_SIGNATURE = 67324752;
  var FIXED_TIMESTAMP = new Date(Date.UTC(1980, 0, 1, 0, 0, 0));
  function getDefaultZipEntryTimestamp() {
    return new Date(FIXED_TIMESTAMP.getTime());
  }
  function readZipPackage(data) {
    const diagnostics = [];
    const entries = [];
    const centralDirectory = readCentralDirectory(data, diagnostics);
    for (const central of centralDirectory) {
      try {
        const localNameLength = readUint16(data, central.localHeaderOffset + 26);
        const localExtraLength = readUint16(data, central.localHeaderOffset + 28);
        const dataStart = central.localHeaderOffset + 30 + localNameLength + localExtraLength;
        const compressed = data.slice(dataStart, dataStart + central.compressedSize);
        const entryData = central.method === 0 ? compressed : getNodeZlib().inflateRawSync(compressed);
        entries.push({
          path: central.path,
          data: new Uint8Array(entryData),
          compression: central.method === 0 ? "store" : "deflate",
          compressedSize: central.compressedSize,
          uncompressedSize: central.uncompressedSize,
          crc32: central.crc,
          modifiedAt: central.modifiedAt
        });
      } catch (error) {
        diagnostics.push(
          createDiagnostic(
            "error",
            "zip.entry.read_failed",
            error instanceof Error ? error.message : String(error),
            central.path
          )
        );
      }
    }
    return { entries, diagnostics };
  }
  async function readZipPackageAsync(data, options = {}) {
    const diagnostics = [];
    const entries = [];
    const centralDirectory = readCentralDirectory(data, diagnostics);
    for (const central of centralDirectory) {
      try {
        const localNameLength = readUint16(data, central.localHeaderOffset + 26);
        const localExtraLength = readUint16(data, central.localHeaderOffset + 28);
        const dataStart = central.localHeaderOffset + 30 + localNameLength + localExtraLength;
        const compressed = data.slice(dataStart, dataStart + central.compressedSize);
        const entryData = central.method === 0 ? compressed : await inflateZipRawAsync(compressed, central.uncompressedSize, central.path, options.inflateRaw);
        entries.push({
          path: central.path,
          data: new Uint8Array(entryData),
          compression: central.method === 0 ? "store" : "deflate",
          compressedSize: central.compressedSize,
          uncompressedSize: central.uncompressedSize,
          crc32: central.crc,
          modifiedAt: central.modifiedAt
        });
      } catch (error) {
        diagnostics.push(
          createDiagnostic(
            "error",
            "zip.entry.read_failed",
            error instanceof Error ? error.message : String(error),
            central.path
          )
        );
      }
    }
    return { entries, diagnostics };
  }
  function writeZipPackage(entries, options = {}) {
    var _a, _b, _c, _d;
    const timestamp = (_a = options.timestamp) != null ? _a : FIXED_TIMESTAMP;
    const compression = (_b = options.compression) != null ? _b : "store";
    const order = (_c = options.order) != null ? _c : "stable";
    const prepared = entries.map((entry) => {
      var _a2, _b2;
      return {
        path: normalizeOpcPartPath(entry.path),
        data: asBytes(entry.data),
        compression: (_a2 = entry.compression) != null ? _a2 : compression,
        modifiedAt: (_b2 = entry.modifiedAt) != null ? _b2 : timestamp
      };
    });
    if (order === "stable") {
      prepared.sort((a, b) => compareOpcPartPaths(a.path, b.path));
    }
    const localParts = [];
    const centralParts = [];
    let offset = 0;
    for (const entry of prepared) {
      const nameBytes = textEncoder.encode(entry.path);
      const method = entry.compression === "store" ? 0 : 8;
      const compressed = entry.compression === "store" ? entry.data : new Uint8Array(getNodeZlib().deflateRawSync(entry.data, { level: (_d = options.compressionLevel) != null ? _d : 9 }));
      const crc = crc32(entry.data);
      const dosTime = toDosTime(entry.modifiedAt);
      const dosDate = toDosDate(entry.modifiedAt);
      const localHeader = new Uint8Array(30 + nameBytes.length);
      writeUint32(localHeader, 0, LOCAL_FILE_SIGNATURE);
      writeUint16(localHeader, 4, 20);
      writeUint16(localHeader, 6, 2048);
      writeUint16(localHeader, 8, method);
      writeUint16(localHeader, 10, dosTime);
      writeUint16(localHeader, 12, dosDate);
      writeUint32(localHeader, 14, crc);
      writeUint32(localHeader, 18, compressed.length);
      writeUint32(localHeader, 22, entry.data.length);
      writeUint16(localHeader, 26, nameBytes.length);
      writeUint16(localHeader, 28, 0);
      localHeader.set(nameBytes, 30);
      localParts.push(localHeader, compressed);
      const centralHeader = new Uint8Array(46 + nameBytes.length);
      writeUint32(centralHeader, 0, CENTRAL_DIRECTORY_SIGNATURE);
      writeUint16(centralHeader, 4, 20);
      writeUint16(centralHeader, 6, 20);
      writeUint16(centralHeader, 8, 2048);
      writeUint16(centralHeader, 10, method);
      writeUint16(centralHeader, 12, dosTime);
      writeUint16(centralHeader, 14, dosDate);
      writeUint32(centralHeader, 16, crc);
      writeUint32(centralHeader, 20, compressed.length);
      writeUint32(centralHeader, 24, entry.data.length);
      writeUint16(centralHeader, 28, nameBytes.length);
      writeUint16(centralHeader, 30, 0);
      writeUint16(centralHeader, 32, 0);
      writeUint16(centralHeader, 34, 0);
      writeUint16(centralHeader, 36, 0);
      writeUint32(centralHeader, 38, 0);
      writeUint32(centralHeader, 42, offset);
      centralHeader.set(nameBytes, 46);
      centralParts.push(centralHeader);
      offset += localHeader.length + compressed.length;
    }
    const centralDirectory = concatBytes(centralParts);
    const end = new Uint8Array(22);
    writeUint32(end, 0, EOCD_SIGNATURE);
    writeUint16(end, 4, 0);
    writeUint16(end, 6, 0);
    writeUint16(end, 8, prepared.length);
    writeUint16(end, 10, prepared.length);
    writeUint32(end, 12, centralDirectory.length);
    writeUint32(end, 16, offset);
    writeUint16(end, 20, 0);
    return concatBytes([...localParts, centralDirectory, end]);
  }
  function getZipEntry(entries, entryPath) {
    const normalized = normalizeOpcPartPath(entryPath);
    return entries.find((entry) => entry.path === normalized);
  }
  function getZipTextEntry(entries, entryPath) {
    const entry = getZipEntry(entries, entryPath);
    return entry === void 0 ? void 0 : textDecoder.decode(entry.data);
  }
  function upsertZipEntry(entries, entry) {
    const normalized = normalizeOpcPartPath(entry.path);
    const next = entries.filter((item) => normalizeOpcPartPath(item.path) !== normalized);
    next.push({ ...entry, path: normalized });
    return next;
  }
  function readCentralDirectory(data, diagnostics) {
    const eocdOffset = findEndOfCentralDirectory(data);
    if (eocdOffset < 0) {
      diagnostics.push(createDiagnostic("error", "zip.eocd.missing", "End of central directory was not found."));
      return [];
    }
    const entryCount = readUint16(data, eocdOffset + 10);
    const centralDirectoryOffset = readUint32(data, eocdOffset + 16);
    const entries = [];
    let offset = centralDirectoryOffset;
    for (let index = 0; index < entryCount; index += 1) {
      if (readUint32(data, offset) !== CENTRAL_DIRECTORY_SIGNATURE) {
        diagnostics.push(createDiagnostic("error", "zip.central_directory.invalid", "Central directory entry signature is invalid."));
        break;
      }
      const flags = readUint16(data, offset + 8);
      const method = readUint16(data, offset + 10);
      const time = readUint16(data, offset + 12);
      const date = readUint16(data, offset + 14);
      const crc = readUint32(data, offset + 16);
      const compressedSize = readUint32(data, offset + 20);
      const uncompressedSize = readUint32(data, offset + 24);
      const fileNameLength = readUint16(data, offset + 28);
      const extraLength = readUint16(data, offset + 30);
      const commentLength = readUint16(data, offset + 32);
      const localHeaderOffset = readUint32(data, offset + 42);
      const nameStart = offset + 46;
      const path = textDecoder.decode(data.slice(nameStart, nameStart + fileNameLength));
      if (method !== 0 && method !== 8) {
        diagnostics.push(createDiagnostic("error", "zip.compression.unsupported", `Unsupported ZIP compression method: ${method}`, path));
      } else {
        entries.push({
          path: normalizeOpcPartPath(path),
          method,
          flags,
          crc,
          compressedSize,
          uncompressedSize,
          localHeaderOffset,
          modifiedAt: fromDosDateTime(date, time)
        });
      }
      offset = nameStart + fileNameLength + extraLength + commentLength;
    }
    return entries;
  }
  function findEndOfCentralDirectory(data) {
    const minOffset = Math.max(0, data.length - 65535 - 22);
    for (let offset = data.length - 22; offset >= minOffset; offset -= 1) {
      if (readUint32(data, offset) === EOCD_SIGNATURE) {
        return offset;
      }
    }
    return -1;
  }
  function toDosTime(date) {
    return date.getUTCHours() << 11 | date.getUTCMinutes() << 5 | Math.floor(date.getUTCSeconds() / 2);
  }
  function toDosDate(date) {
    const year = Math.max(1980, date.getUTCFullYear());
    return year - 1980 << 9 | date.getUTCMonth() + 1 << 5 | date.getUTCDate();
  }
  function fromDosDateTime(date, time) {
    const year = 1980 + (date >>> 9 & 127);
    const month = date >>> 5 & 15;
    const day = date & 31;
    const hour = time >>> 11 & 31;
    const minute = time >>> 5 & 63;
    const second = (time & 31) * 2;
    return new Date(Date.UTC(year, month - 1, day, hour, minute, second));
  }
  async function inflateZipRawAsync(compressed, expectedSize, path, customInflateRaw) {
    const inflated = customInflateRaw === void 0 ? await defaultInflateZipRawAsync(compressed) : await customInflateRaw(compressed, expectedSize, path);
    const bytes = new Uint8Array(inflated);
    if (bytes.length !== expectedSize) {
      throw new Error(`Deflated ZIP entry size mismatch: ${path}`);
    }
    return bytes;
  }
  async function defaultInflateZipRawAsync(compressed) {
    const runtime = globalThis;
    if (typeof runtime.DecompressionStream === "function") {
      try {
        const stream = new Blob([compressed]).stream().pipeThrough(new runtime.DecompressionStream("deflate-raw"));
        const buffer = await new Response(stream).arrayBuffer();
        return new Uint8Array(buffer);
      } catch (_error) {
      }
    }
    return new Uint8Array(getNodeZlib().inflateRawSync(compressed));
  }
  function getNodeZlib() {
    var _a, _b;
    const runtime = globalThis;
    const getBuiltinModule = (_a = runtime.process) == null ? void 0 : _a.getBuiltinModule;
    const zlib = typeof getBuiltinModule === "function" ? (_b = getBuiltinModule("node:zlib")) != null ? _b : getBuiltinModule("zlib") : void 0;
    if (zlib !== void 0 && typeof zlib.deflateRawSync === "function" && typeof zlib.inflateRawSync === "function") {
      return zlib;
    }
    throw new Error("Node zlib is required for synchronous ZIP deflate operations. Use stored entries, readZipPackageAsync with DecompressionStream, or inject an async inflater.");
  }
  function readOfficePackage(data) {
    const zip = readZipPackage(data);
    return buildOfficePackageFromZipReadResult(zip.entries, zip.diagnostics);
  }
  async function readOfficePackageAsync(data, options = {}) {
    const zip = await readZipPackageAsync(data, options);
    return buildOfficePackageFromZipReadResult(zip.entries, zip.diagnostics);
  }
  function buildOfficePackageFromZipReadResult(entries, zipDiagnostics) {
    const diagnostics = [...zipDiagnostics];
    const contentTypesXml = getZipTextEntry(entries, "[Content_Types].xml");
    let contentTypes;
    if (contentTypesXml === void 0) {
      diagnostics.push(
        createDiagnostic(
          "warning",
          "opc.content_types.missing",
          "The package does not contain [Content_Types].xml.",
          "[Content_Types].xml"
        )
      );
    } else {
      contentTypes = parseOpcContentTypesXml(contentTypesXml);
    }
    return contentTypes === void 0 ? { entries, diagnostics } : { entries, contentTypes, diagnostics };
  }
  function listOfficeMediaParts(entries) {
    return entries.filter((entry) => normalizeOpcPartPath(entry.path).includes("/media/"));
  }
  function readOfficePartRelationships(entries, sourcePartPath, options = {}) {
    const relsXml = getZipTextEntry(entries, buildOpcRelationshipsPath(sourcePartPath));
    if (relsXml === void 0) {
      return [];
    }
    const relationships = parseOpcRelationshipsXml(relsXml);
    return options.resolveTargets === false ? relationships : resolveOpcRelationships(relationships, sourcePartPath);
  }
  return __toCommonJS(stdin_exports);
})();

(() => {
  (globalThis).__mikuprojectMsOfficeCore = __mikuMsOfficeCoreRelease;
})();
